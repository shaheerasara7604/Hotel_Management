

<div align="center">
  <a href="https://github.com/othneildrew/Best-README-Template">
    <img src="IMAGES/hotel-paradise.png" alt="Logo" width="190" height="190">
  </a>

<h3 align="center">Hotel Paradise</h3>

<p align="center">
    <b>Online Website for Hotel Management Company</b>
    <br />
  </p>
  <a  href="https://hotel-paradise.github.io " target="blank" >View Demo</a>
</div>

<br>
<br>

The more tourism industries growing, there is continuous demanding for hotel rooms . Travelers usually take rest to safe and calm place , so in this era of Tech an online site for hotel room booking from anywhere across country makes Travelers tension free about his staying while they are  on a Tour.
<br>
<hr>
<b>Hosting server : &nbsp; Github Pages</b>



